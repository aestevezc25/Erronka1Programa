package bussineslogic;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

import eredua.Bezeroa;
import ikuspegia.Kontsola;

public class BezeroKudeatzaile {
    private String bezeroFitxategiIzena;
    private Map<String, Bezeroa> mapa = new HashMap<>();

    public BezeroKudeatzaile() {
        this.bezeroFitxategiIzena = "./src/fitxategiak/bezeroak.txt";
    }

    public void fitxategiakIrakurri() {
        try (BufferedReader br = new BufferedReader(new FileReader(bezeroFitxategiIzena))) {
            br.readLine();
            String lerroa;
            while ((lerroa = br.readLine()) != null) {
                String[] tokenak = lerroa.split("\t");
                if (tokenak.length >= 5) {
                    Bezeroa b = new Bezeroa();
                    b.setId(tokenak[0]);
                    b.setIzena(tokenak[1]);
                    b.setAbizena(tokenak[2]);
                    b.setHelbidea(tokenak[3]);
                    b.setEmaila(tokenak[4]);
                    mapa.put(tokenak[0], b);
                }
            }
        } catch (Exception e) {
            Kontsola.idatzi("Errorea bezeroak irakurtzean: " + e.getMessage());
        }
    }

    public void bilatuEtaInprimatu(String id) {
        if (mapa.isEmpty()) {
            fitxategiakIrakurri();
        }

        Bezeroa b = mapa.get(id);

        if (b != null) {
            Kontsola.idatzi("\n--- BEZEROEN INFORMAZIOA ---");
            Kontsola.idatzi("Izen-abizenak: " + b.getIzena() + " " + b.getAbizena());
            Kontsola.idatzi("Helbidea: " + b.getHelbidea());
            Kontsola.idatzi("Emaila: " + b.getEmaila());
        } else {
            Kontsola.idatzi("Bezero hori ez da existitzen (ID: " + id + "). Saiatu berriro.");
        }
    }
}